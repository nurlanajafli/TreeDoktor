import Bold from './bold';

class Strike extends Bold {}
Strike.blotName = 'strike';
Strike.tagName = ['S', 'STRIKE'];

export default Strike;
